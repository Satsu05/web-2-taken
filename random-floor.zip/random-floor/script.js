
let oef1 = Math.random() * 255;
console.log('getal tussen 0 en 255 ' + oef1);
let oef2 = Math.floor(oef1);
console.log('afgerond getal ' + oef2)