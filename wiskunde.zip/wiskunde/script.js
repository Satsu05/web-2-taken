
//alert = popup
let getal1 = prompt("geef het eerste getal");
let getal2 = prompt("geef het 2de getal");
//let som = (getal1*1)+(getal2*2);
//alert(som);
//if (getal1>getal2) {alert("getal1 is groter dan getal2")}else{alert("getal1 is kleiner dan getal2")}
let getal1KleinerGetal2 = getal1 < getal2
if (getal1KleinerGetal2) {alert("getal1 is kleiner dan getal2")}//juist
else{alert("getal1 is groter dan getal2")}//fout